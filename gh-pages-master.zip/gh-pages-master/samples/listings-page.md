---
layout: listings
colorspace: purple
listings:
  'Featured':
    'React Dev Tools':
      link: '#example'
      icon: '/assets/images/candies.png'
    'Slack':
      link: '#example'
      icon: '/assets/images/candies.png'
  'Code Editors':
    'Vim':
      link: '#example'
      icon: '/assets/images/candies.png'
    'Sublime':
      link: '#example'
      icon: '/assets/images/candies.png'
    'Xcode':
      link: '#example'
      icon: '/assets/images/candies.png'
---

Below you will find an example of the structure of a listings page with some filler content that goes nowhere.

[Documentation](../docs/listings-pages){: .button}
